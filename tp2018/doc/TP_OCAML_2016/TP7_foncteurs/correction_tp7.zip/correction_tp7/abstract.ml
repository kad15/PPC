module type DOMAIN = sig
  type t
  val fprint : out_channel -> t -> unit
  val cst : float -> t
  val sum : t -> t -> t
  val mul : t -> t -> t
  val cond : t -> t -> t -> t
end

module type S = sig
  type dom
  type t
  val cst : float -> t
  val var : string -> t
  val ( + ) : t -> t -> t
  val ( * ) : t -> t -> t
  val cond : t -> t -> t -> t
  val eval : (string * dom) list -> t -> dom
end
  
module Make = functor (Dom : DOMAIN) -> struct
  type dom = Dom.t
  type t =
      Cst of float
    | Var of string
    | Sum of t * t
    | Mul of t * t
    | Cond of t * t * t

  let cst = fun c -> Cst c
  let var = fun s -> Var s
  let ( + ) = fun g d -> Sum (g, d)
  let ( * ) = fun g d -> Mul (g, d)
  let cond = fun c t e -> Cond (c, t, e)

  let eval = fun env e ->
    let rec eval_rec = fun e ->
      match e with
        Cst f -> Dom.cst f
      | Var s -> List.assoc s env
      | Sum (g, d) -> Dom.sum (eval_rec g) (eval_rec d)
      | Mul (g, d) -> Dom.mul (eval_rec g) (eval_rec d)
      | Cond (c, t, e) -> Dom.cond (eval_rec c) (eval_rec t) (eval_rec e) in
    eval_rec e
end
