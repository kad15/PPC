module FloatAttr = Fcl_float_var.FloatAttr
module FloatVar = Fcl_float_var.FloatVar
module FloatGoals = Fcl_float_goals
module FloatDomain = Fcl_float_domain
module FloatInterval = Fcl_float_interval
module FloatCstr = Fcl_float_cstr
module FloatArith = Fcl_float_arith
module FloatArray = Fcl_float_array
