module Sign = struct
  type t = Plus | Minus | Unk

  let fprint = fun ch s ->
    let str =
      match s with
        Plus -> "+"
      | Minus -> "-"
      | Unk -> "?" in
    Printf.fprintf ch "%s" str

  let cst = fun c ->
    if c >= 0. then Plus else Minus

  let sum = fun g d ->
    match g, d with
      Plus, Plus -> Plus
    | Minus, Minus -> Minus
    | _, _ -> Unk

  let sum = fun g d ->
    if g = d then d else Unk

  let mul = fun g d ->
    match g, d with
      Plus, Plus | Minus, Minus -> Plus
    | Plus, Minus | Minus, Plus -> Minus
    | _, _ -> Unk

  let cond = fun c t e ->
    match c with
      Plus -> t
    | Minus -> e
    | Unk -> if t = e then t else Unk
end

module AbstractSign = Abstract.Make(Sign)

open AbstractSign

let test_sign = fun () ->
  let x = var "x" in
  let y = var "y" in
  let e = cond (x + cst (-1.) * y) x (cst 1. + cst 3.) in

  (* Plus *)
  Printf.printf "%a\n" Sign.fprint
    (eval [("x", Sign.Plus); ("y", Sign.Unk)] e);
  Printf.printf "%a\n" Sign.fprint
    (eval [("x", Sign.Plus); ("y", Sign.Plus)] e);
  Printf.printf "%a\n" Sign.fprint
    (eval [("x", Sign.Plus); ("y", Sign.Minus)] e);
  (* Unk *)
  Printf.printf "%a\n" Sign.fprint
    (eval [("x", Sign.Minus); ("y", Sign.Unk)] e);
  Printf.printf "%a\n" Sign.fprint
    (eval [("x", Sign.Minus); ("y", Sign.Minus)] e);
  (* Plus *)
  Printf.printf "%a\n" Sign.fprint
    (eval [("x", Sign.Minus); ("y", Sign.Plus)] e)

module Interval = struct
  type t = float * float

  let fprint = fun ch (a, b) ->
    Printf.fprintf ch "(%g,%g)" a b

  let cst = fun c -> (c, c)

  let sum = fun (a, b) (c, d) -> (a +. c, b +. d)

  let mul = fun (a, b) (c, d) ->
    if a >= 0. then
      if c >= 0. then (a *. c, b *. d)
      else if d < 0. then (b *. c, a *. d)
      else (b *. c, b *. d)
    else if b < 0. then
      if c >= 0. then (a *. d, b *. c)
      else if d < 0. then (b *. d, a *. c)
      else (a *. d, a *. c)
    else
      if c >= 0. then (a *. d, b *. d)
      else if d < 0. then (b *. c, a *. c)
      else (min (b *. c) (a *. d), max (a *. c) (b *. d))

  let cond = fun (a, b) ((c, d) as cd) ((e, f) as ef) ->
    if a >= 0. then cd
    else if b < 0. then ef
    else (min c e, max d f) 
end

module AbstractInter = Abstract.Make(Interval)

open AbstractInter

let test_inter = fun () ->
  let x = var "x" in
  let y = var "y" in
  let e = cond (x + cst (-1.) * y) x (cst 1. + cst 3.) in

  Printf.printf "%a\n" Interval.fprint
    (eval [("x", (10., 20.)); ("y", (10., 20.))] e);
  Printf.printf "%a\n" Interval.fprint
    (eval [("x", (10., 20.)); ("y", (2., 8.))] e)

let () =
  test_sign ();
  test_inter ()
